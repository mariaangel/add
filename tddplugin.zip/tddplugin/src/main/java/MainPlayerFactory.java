import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;
import com.intellij.ui.CollectionListModel;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import com.intellij.uiDesigner.core.GridLayoutManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MainPlayerFactory implements ToolWindowFactory {

    private JButton continueBtn;
    private JPanel mainPanel;
    private CollectionListModel statuses;
    private CollectionListModel guidelines;
    private List<String> status;
    private List<String> statusContent;
    private List<Color> colors;
    private JTextArea colorArea;
    private JTextArea statusArea;
    private JTextArea guidelineArea;

    private int index;

    public MainPlayerFactory() {
        continueBtn.addActionListener(e -> nextPhase());
    }

    private void createUIComponents() {
        status = new ArrayList();
        status.add("Failing Test");
        status.add("Failing Test");
        status.add ("Implementation");
        status.add("Refactor");
        status.add("Refactor");
        statusContent = new ArrayList();
        statusContent.add("Edge cases");
        statusContent.add("Requirements");
        statusContent.add ("Implementation");
        statusContent.add("Test refactoring");
        statusContent.add("Implementation refactoring");
        colors = new ArrayList<>();
        colors.add(Color.RED);
        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.BLUE);
        colors.add(Color.BLUE);

        index = 0;
        statuses = new CollectionListModel<List>(new ArrayList<>());
        guidelines = new CollectionListModel<List>(new ArrayList<>());

        mainPanel = new JPanel();
        GridLayout grid = new GridLayout(2,3);
        mainPanel.setLayout(grid);
        mainPanel.validate();

        JPanel statusPanel = new JPanel();

        statusArea = new JTextArea();
        statusArea.append(status.get(index));
        guidelineArea = new JTextArea();
        guidelineArea.append(statusContent.get(index));
        colorArea = new JTextArea();
        colorArea.append(" ");
        colorArea.setBackground(colors.get(index));

        mainPanel.add(colorArea);
        statusPanel.add(statusArea);
        mainPanel.add(statusPanel);
        mainPanel.add(continueBtn);
        mainPanel.add(guidelineArea);

        index++;
        //guidelinePanel.add(guidelineList);
    }

    private void nextPhase() {
        statusArea.setText("");
        guidelineArea.setText("");
        statusArea.append(status.get(index));
        guidelineArea.append(statusContent.get(index));
        colorArea.setBackground(colors.get(index));
        index = index >= status.size() - 1 ? 0 : index + 1;
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    @Override
    public void createToolWindowContent(@NotNull Project project, @NotNull ToolWindow toolWindow) {
        createUIComponents();
        ContentFactory contentFactory = ContentFactory.SERVICE.getInstance();
        Content content = contentFactory.createContent(mainPanel, "", false);
        toolWindow.getContentManager().addContent(content);
    }
}
